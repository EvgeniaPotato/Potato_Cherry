
package MainClasses.Beings;

import MainClasses.Being;

public class Animal extends Being{
    
    int NumberOfVolier;
    
    public void Walking()
    {
        
    }
    
    public void Eating()
    {
        
    }
}
