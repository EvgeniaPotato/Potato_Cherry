
package MainClasses;


public abstract class Being {
    private String name;
    private int age;
    
    public abstract void Walking();
    public abstract void Eating();
}
