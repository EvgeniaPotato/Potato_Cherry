
package MainClasses;

public abstract class FoodType {
    
    int massa;
    
    public abstract void Cooking();
    public abstract void WhoCanEat();
}
