
package MainClasses.Beings;

import MainClasses.Being;
import Interfaces.Working;

public class Emloyee extends Being implements Working{
    private double Salary;
    
    public void Walking()
    {
        
    }
    
    public void Eating()
    {
        
    }
    
    public void PetAnimals()
    {
        
    }
    
    public void Cleaning()
    {
        
    }
}
