
package animals;

import MainClasses.Beings.Animal;

public class Giraffe extends Animal{
    
}
