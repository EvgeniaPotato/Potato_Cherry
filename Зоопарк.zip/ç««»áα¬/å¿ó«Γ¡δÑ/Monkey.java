
package animals;

import MainClasses.Beings.Animal;

public class Monkey extends Animal{
    
}
