
package zoo;
import animals.Pinguin;
import animals.Monkey;
import animals.Giraffe;

 class Zoo {
 
    public static void main(String[] args) {
    Pinguin pinguin = new Pinguin();
    pinguin.Swim();
    }
    
}
