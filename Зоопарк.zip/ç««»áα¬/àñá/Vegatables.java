
package food;

import Interfaces.Eatable;
import MainClasses.FoodType;

public class Vegatables extends FoodType implements Eatable{
    String TypeOfVegatables;
    
    public void Cooking()
    {
        
    }
    
    public void WhoCanEat()
    {
        
    }
    
    public void Eatable()
    {
        
    }
}
