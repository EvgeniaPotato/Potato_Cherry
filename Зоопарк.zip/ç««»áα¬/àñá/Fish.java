
package food;

import Interfaces.Eatable;
import MainClasses.FoodType;

public class Fish extends FoodType implements Eatable{
    
    String Fishname;
    
    public void Cooking()
    {
        
    }
    
    public void WhoCanEat()
    {
        
    }
    
    public void Eatable()
    {
        
    }
}
