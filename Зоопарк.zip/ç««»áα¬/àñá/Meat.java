
package food;

import Interfaces.Eatable;
import MainClasses.FoodType;


public class Meat extends FoodType implements Eatable{
    
    int MeatType;
    
    public void Cooking()
    {
        
    }
    
    public void WhoCanEat()
    {
        
    }
    
    public void Eatable()
    {
        
    }
}
