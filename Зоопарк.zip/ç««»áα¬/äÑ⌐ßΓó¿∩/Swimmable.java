
package Interfaces;


public interface Swimmable {
    public void Swim();
}
