
package Interfaces;

public interface Eatable {
    public void Eatable();
}
