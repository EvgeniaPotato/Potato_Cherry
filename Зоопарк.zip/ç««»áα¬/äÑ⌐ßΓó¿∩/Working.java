
package Interfaces;


public interface Working {
    public void PetAnimals();
    public void Cleaning();
}
